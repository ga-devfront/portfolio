-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Client :  localhost:3306
-- Généré le :  Mer 12 Février 2020 à 18:31
-- Version du serveur :  5.7.28-0ubuntu0.18.04.4
-- Version de PHP :  7.2.24-0ubuntu0.18.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `express_food`
--

-- --------------------------------------------------------

--
-- Structure de la table `Adress`
--

CREATE TABLE `Adress` (
  `id` int(11) NOT NULL,
  `User_id` int(11) NOT NULL,
  `completName` varchar(45) NOT NULL,
  `wayName` varchar(45) NOT NULL,
  `adressName` varchar(45) NOT NULL,
  `wayNumber` varchar(45) NOT NULL,
  `street` varchar(45) NOT NULL,
  `zipCode` int(11) NOT NULL,
  `additionalAdress` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `Adress`
--

INSERT INTO `Adress` (`id`, `User_id`, `completName`, `wayName`, `adressName`, `wayNumber`, `street`, `zipCode`, `additionalAdress`) VALUES
(1, 1, 'Alexis Guyomar', 'Route du rache', 'Maison', '45', 'Lyon', 69000, ''),
(2, 1, 'Guyomar Alexis', 'Rue du four', 'Travail', '41', 'Lyon', 69100, '5eme étage'),
(3, 2, 'Emilie Grare', 'Route des allobroges', 'Maison', '2bis', 'Annemasse', 74100, '');

-- --------------------------------------------------------

--
-- Structure de la table `Cart`
--

CREATE TABLE `Cart` (
  `id` int(11) NOT NULL,
  `Dish_id` int(11) NOT NULL,
  `Order_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `Cart`
--

INSERT INTO `Cart` (`id`, `Dish_id`, `Order_id`, `quantity`) VALUES
(1, 5, 5, 1),
(2, 7, 5, 2),
(3, 6, 5, 1),
(4, 2, 6, 1),
(5, 1, 7, 2),
(6, 3, 7, 1),
(7, 4, 7, 1);

-- --------------------------------------------------------

--
-- Structure de la table `Delivrer`
--

CREATE TABLE `Delivrer` (
  `id` int(11) NOT NULL,
  `User_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `Delivrer`
--

INSERT INTO `Delivrer` (`id`, `User_id`) VALUES
(1, 3);

-- --------------------------------------------------------

--
-- Structure de la table `Dish`
--

CREATE TABLE `Dish` (
  `id` int(11) NOT NULL,
  `dishName` varchar(45) NOT NULL,
  `unitPrice` decimal(3,0) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `Dish`
--

INSERT INTO `Dish` (`id`, `dishName`, `unitPrice`, `date`) VALUES
(1, 'Lasagnes', '8', '2020-02-12'),
(2, 'Paella', '10', '2020-02-12'),
(3, 'Tiramisu', '3', '2020-02-12'),
(4, 'Tarte aux pommes', '4', '2020-02-12'),
(5, 'Lasagnes', '8', '2020-02-11'),
(6, 'Tourte', '7', '2020-02-11'),
(7, 'Brownie', '3', '2020-02-11'),
(8, 'Crème caramel', '5', '2020-02-11');

-- --------------------------------------------------------

--
-- Structure de la table `Order`
--

CREATE TABLE `Order` (
  `id` int(11) NOT NULL,
  `date` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `Adress_id` int(11) NOT NULL,
  `User_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `Order`
--

INSERT INTO `Order` (`id`, `date`, `Adress_id`, `User_id`) VALUES
(5, '2020-02-11 11:13:06.056259', 1, 1),
(6, '2020-02-12 11:19:04.064000', 2, 1),
(7, '2020-02-12 12:02:04.040017', 3, 2);

-- --------------------------------------------------------

--
-- Structure de la table `Stock`
--

CREATE TABLE `Stock` (
  `id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `Dish_id` int(11) NOT NULL,
  `Delivrer_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `Stock`
--

INSERT INTO `Stock` (`id`, `quantity`, `Dish_id`, `Delivrer_id`) VALUES
(1, 5, 1, 1),
(2, 3, 2, 1),
(3, 3, 3, 1),
(4, 3, 4, 1);

-- --------------------------------------------------------

--
-- Structure de la table `User`
--

CREATE TABLE `User` (
  `id` int(11) NOT NULL,
  `username` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `firstName` varchar(45) NOT NULL,
  `secondName` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `User`
--

INSERT INTO `User` (`id`, `username`, `email`, `firstName`, `secondName`, `password`) VALUES
(1, 'alexg74', 'alexis.guyomar@hotmail.fr', 'Alexis', 'Guyomar', 'fr#521AAli245'),
(2, 'rinea66', 'emilie.g@orange.fr', 'Emilie', 'Grare', '3fok4mf4#a'),
(3, 'secco123', 'secco.aurelien@gmail.com', 'Aurelien', 'Secco', '12@splouFy34');

--
-- Index pour les tables exportées
--

--
-- Index pour la table `Adress`
--
ALTER TABLE `Adress`
  ADD PRIMARY KEY (`id`,`User_id`),
  ADD KEY `fk_Adress_User1_idx` (`User_id`);

--
-- Index pour la table `Cart`
--
ALTER TABLE `Cart`
  ADD PRIMARY KEY (`id`,`Dish_id`,`Order_id`),
  ADD KEY `fk_Cart_Order1_idx` (`Order_id`),
  ADD KEY `fk_Cart_Dish1_idx` (`Dish_id`);

--
-- Index pour la table `Delivrer`
--
ALTER TABLE `Delivrer`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_Delivrer_User1_idx` (`User_id`);

--
-- Index pour la table `Dish`
--
ALTER TABLE `Dish`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `Order`
--
ALTER TABLE `Order`
  ADD PRIMARY KEY (`id`,`Adress_id`,`User_id`),
  ADD KEY `fk_Order_Adress1_idx` (`Adress_id`),
  ADD KEY `fk_Order_User1_idx` (`User_id`);

--
-- Index pour la table `Stock`
--
ALTER TABLE `Stock`
  ADD PRIMARY KEY (`id`,`Dish_id`,`Delivrer_id`),
  ADD KEY `fk_Stock_Dish1_idx` (`Dish_id`),
  ADD KEY `fk_Stock_Delivrer1_idx` (`Delivrer_id`);

--
-- Index pour la table `User`
--
ALTER TABLE `User`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `Adress`
--
ALTER TABLE `Adress`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `Cart`
--
ALTER TABLE `Cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT pour la table `Delivrer`
--
ALTER TABLE `Delivrer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `Dish`
--
ALTER TABLE `Dish`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT pour la table `Order`
--
ALTER TABLE `Order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT pour la table `Stock`
--
ALTER TABLE `Stock`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT pour la table `User`
--
ALTER TABLE `User`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `Adress`
--
ALTER TABLE `Adress`
  ADD CONSTRAINT `fk_Adress_User1` FOREIGN KEY (`User_id`) REFERENCES `User` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `Cart`
--
ALTER TABLE `Cart`
  ADD CONSTRAINT `fk_Cart_Dish1` FOREIGN KEY (`Dish_id`) REFERENCES `Dish` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Cart_Order1` FOREIGN KEY (`Order_id`) REFERENCES `Order` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `Delivrer`
--
ALTER TABLE `Delivrer`
  ADD CONSTRAINT `fk_Delivrer_User1` FOREIGN KEY (`User_id`) REFERENCES `User` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `Order`
--
ALTER TABLE `Order`
  ADD CONSTRAINT `fk_Order_Adress1` FOREIGN KEY (`Adress_id`) REFERENCES `Adress` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Order_User1` FOREIGN KEY (`User_id`) REFERENCES `User` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `Stock`
--
ALTER TABLE `Stock`
  ADD CONSTRAINT `fk_Stock_Delivrer1` FOREIGN KEY (`Delivrer_id`) REFERENCES `Delivrer` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Stock_Dish1` FOREIGN KEY (`Dish_id`) REFERENCES `Dish` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
